///Switch light/dark mode

document.querySelectorAll('.moon-sun').forEach(item => {
    item.addEventListener('click', switchMode)
  });
  
  if(localStorage.getItem('mode')) {
    let body = document.querySelector('body');
    body.dataset.theme = localStorage.getItem('mode');
  }
  
  function switchMode() {
    let body = document.querySelector('body');
    let mode = this.dataset.mode;
    
    if(mode === 'dark') {
      body.dataset.theme ='dark';
     localStorage.setItem('mode', 'dark');
      
    } else {
      body.dataset.theme ='light';
      localStorage.setItem('mode','light');
      
    }
  }
  