/////////////////////////clic logo ---> retour accueil/////////////////////////////////

document.querySelector('#logo-web').addEventListener('click', goIndex);
function goIndex() {
    location.href = 'index.html';
}

////////DROPDOWN MENU

let burger = document.querySelector('#burger');
burger.addEventListener('click', openMenu);

function openMenu() {
document.querySelector('ol').style.display = 'block';
}

//Close menu (mobile)
window.addEventListener('click', menuClose);

function menuClose(event) {
if (event.target.matches('.relative-menusearch')) {
document.querySelector('.file').style.display = 'none';
}

}

//desktop
let drop = document.querySelector('.relative-menusearch__mainMenu');
drop.addEventListener('click',openFile);

function openFile(){
document.querySelector('.file').style.display = 'block';
}

window.addEventListener('click', fileClose);

function fileClose(event) {
if (event.target.matches('#arrow')) {

document.querySelector('.file').style.display ='none';
}
}

////Fetch genres
fetch ('https://api.themoviedb.org/3/genre/movie/list?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR',{
method: 'GET',
headers : {
'Content-Type' : 'application.json'
}
})
.then(response=>response.json())
.then (response =>{
response.genres.forEach(file => {
document.querySelector('.file').innerHTML+= '<li>'+
'<a href="genre.html?id='+file.id+'"<p>'+file.name+'</p></a>'+
'</li>';
});
})
 
 /********************************************************************
  * API FETCH
  * 
  ********************************************************************/


 /** 
 //connexion a l'api via l'URL pour récuperer les détails du film (web & mobile)
 **********************************************************************/
 
let query = window.location.search // ?id=17521
const params = new URLSearchParams(query); // ['id': 17521]

function detailFilm(id) {
 
  let urlDetail = 'https://api.themoviedb.org/3/movie/' + id + '?api_key=02b73bb4996a66e2fb13ce6cd954dfab&language=fr';
  
  fetch(urlDetail, {
      method: "GET",
      headers: {
          'Content-Type': 'application/json'
          
        }
  })
  
  .then(response => response.json())
  .then(movie => {
    console.log(movie); 
    //selection de la class pour afficher l'image récuperée
    document.querySelector('.container__background').style.backgroundImage= 'url("https://www.themoviedb.org/t/p/w1920_and_h800_multi_faces/'+ movie.backdrop_path +'")';
      //selection de la class pour afficher l'image récuperée WEB
      document.querySelector('.container__imgfilm').src="https://image.tmdb.org/t/p/w500/"+ movie.poster_path;
      //affichage du nom WEB
          document.querySelector('.details__film__web__title').textContent = movie.original_title;
         //affichage du nom MOBILE
         document.querySelector('.details__film__mobile__title').textContent = movie.original_title;
          //affichage de la date de sortie WEB
              document.querySelector('.details__film__web__years').textContent = movie.release_date;
              //affichage de la date de sortie MOBILE
              document.querySelector('.details__film__mobile__years').textContent = movie.release_date;
              //affichage du synopsis WEB
              document.querySelector('.details__film__web__synopsis').textContent = movie.overview;
              //affichage du synopsis MOBILE
              document.querySelector('.details__film__mobile__synopsis').textContent = movie.overview;
  
  
  })
  .catch(function(err) {
      console.log('Fetch Error :-S', err);
    });
    
}

detailFilm(params.get("id"));
 
 
 /****************************************
  * Récupération de la filmographie
  * version mobile
  **********************************************/
  const visuelSearch = 'https://image.tmdb.org/t/p/w500';

 fetch(`https://api.themoviedb.org/3/person/287/movie_credits?api_key=d31b3c78860c89e16a7dc07680568b1c&language=en-US`,{

     method : 'GET',
     headers : {
         'Content-Type': 'application/json'
     }
 })
 .then ( response => response.json())
 .then ((films) => {
     films.cast.forEach(film =>{
        let poster;
        if(film.poster_path) {
            poster = `${visuelSearch}${film.poster_path}`;
        }
        else {
            poster = 'img/default.svg';
        }
         document.querySelector('.overflow__mobile__movie').innerHTML+= `<a class="overflow__movie__mobile__img" href="./detail_film.html?id=${film.id}">
         <img class="overflow__movie__mobile__img"
             src="https://image.tmdb.org/t/p/h632${film.poster_path}"
             alt="affiche film">
     </a>`
     })
    
 })
 
 
 /** 
  * Récupération de la filmographie
 //desktop version
 *********************************************************/
 fetch (`https://api.themoviedb.org/3/person/287/movie_credits?api_key=d31b3c78860c89e16a7dc07680568b1c&language=en-US`,{
     method: 'GET',
     headers : {
         'Content-Type': 'application/json'
     }
 })
     .then ( response => response.json())
     .then ((films) =>{
         films.cast.forEach(film =>{
             //selection 
             document.querySelector('.overflow__web__movie').innerHTML+=` <a class="overflow__movie__web__img" href="./detail_film.html?id=${film.id}">
             <img class="overflow__movie__web__img"
                 src="https://image.tmdb.org/t/p/h632${film.poster_path}"
                 alt="affiche film">
         </a>`
         })
     })


/////////////////////////////////FETCH TRAILERS//////////////////////////////////////////////

let queryTrailers = window.location.search; 
const paramsTrailers = new URLSearchParams(queryTrailers); 

  function trailers(id) {

    let urlTrailers = 'https://api.themoviedb.org/3/movie/' + id + '/videos' + '?api_key=02b73bb4996a66e2fb13ce6cd954dfab&language=fr';
   
    fetch(urlTrailers, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json'
            
          }
    })
    
    .then(response => response.json())
    .then(trailer => {
              document.querySelector('.trailers').innerHTML += 
              '<li>' +
              "<p>" + trailer.results[0].name + "</p>" + 
              '<iframe width="100%" height="350px" src="https://www.youtube.com/embed/' + trailer.results[0].key + '" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>' +
              '</iframe>' +
              '</li>';
   
    })
    .catch(function(err) {
        console.log('Fetch Error :-S', err);
      });
      
}

trailers(paramsTrailers.get("id"));

 