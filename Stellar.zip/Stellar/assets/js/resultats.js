/////////////////////////clic logo ---> retour accueil/////////////////////////////////

document.querySelector('#logo-web').addEventListener('click', goIndex);
function goIndex() {
    location.href = 'index.html';
}



////////DROPDOWN MENU

let burger = document.querySelector('#burger');
burger.addEventListener('click', openMenu);

function openMenu() {
document.querySelector('ol').style.display = 'block';
}

//Close menu (mobile)
window.addEventListener('click', menuClose);

function menuClose(event) {
if (event.target.matches('.relative-menusearch')) {
document.querySelector('.file').style.display = 'none';
}

}

//desktop
let drop = document.querySelector('.relative-menusearch__mainMenu');
drop.addEventListener('click',openFile);

function openFile(){
document.querySelector('.file').style.display = 'block';
}

window.addEventListener('click', fileClose);

function fileClose(event) {
if (event.target.matches('#arrow')) {

document.querySelector('.file').style.display ='none';
}
}

////Fetch genres
fetch ('https://api.themoviedb.org/3/genre/movie/list?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR',{
method: 'GET',
headers : {
'Content-Type' : 'application.json'
}
})
.then(response=>response.json())
.then (response =>{
response.genres.forEach(file => {
document.querySelector('.file').innerHTML+= '<li>'+
'<a href="genre.html?id='+file.id+'"<p>'+file.name+'</p></a>'+
'</li>';
});
})


/////////////////////////////FETCH RESULTATS/////////////////////////////////////////////////

const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());
let page = params.page ? Number(params.page) : 1;
 
const API_KEY = 'api_key=02b73bb4996a66e2fb13ce6cd954dfab';
const BASE_URL = 'https://api.themoviedb.org/3';
const API_SEARCH = BASE_URL + '/search/multi?'+ API_KEY + '&language=fr';//url du fetch
const newURL = API_SEARCH + '&query=' + params.mySearch + '&page=' + params.page;
const visuelSearch = 'https://image.tmdb.org/t/p/w500';
  
fetch(newURL)
.then(response => response.json())
.then(movies => {
    console.log(movies);
    movies.results.forEach(result => {
        let poster;
        let title = result.title ?? result.name;

        if(result.poster_path) {
            poster = `${visuelSearch}${result.poster_path}`;
        }
        else {
            poster = 'img/default.svg';
        }

        document.querySelector('.picture__back--firstLine').innerHTML += `
            <a href="detail_film.html?id=${result.id}&media=${result.media_type}">
                <img src="${poster}" alt="${title}">
            </a>
        `;
    });

let right = document.querySelector('.arrow_right'); 

if(page < movies.total_pages) {
    console.log(right);
    right.href = `resultats.html?mySearch=${params.mySearch}&page=${page+1}`;
    right.querySelector('.picture__back--arrows--right').style.display = 'block';
} else {
    right.querySelector('.picture__back--arrows--right').style.display = 'none';
}


    let left = document.querySelector('.arrow_left');  
    if(page >= 2) {
        left.querySelector('.picture__back--arrows--left').style.display = 'block';
        left.href = `resultats.html?mySearch=${params.mySearch}&page=${page-1}`;
    } else {
        left.querySelector('.picture__back--arrows--left').style.display = 'none';
    }
})
.catch(error => console.log(error));

/////////////////////////clic logo ---> retour accueil/////////////////////////////////

document.querySelector('#logo-web').addEventListener('click', goIndex);
function goIndex() {
    location.href = 'index.html';
}
