/////////////////////////clic logo ---> retour accueil/////////////////////////////////

document.querySelector('#logo-web').addEventListener('click', goIndex);
function goIndex() {
    location.href = 'index.html';
}



////////DROPDOWN MENU

let burger = document.querySelector('#burger');
burger.addEventListener('click', openMenu);

function openMenu() {
document.querySelector('ol').style.display = 'block';
}

//Close menu (mobile)
window.addEventListener('click', menuClose);

function menuClose(event) {
if (event.target.matches('.relative-menusearch')) {
document.querySelector('.file').style.display = 'none';
}

}

//desktop
let drop = document.querySelector('.relative-menusearch__mainMenu');
drop.addEventListener('click',openFile);

function openFile(){
document.querySelector('.file').style.display = 'block';
}

window.addEventListener('click', fileClose);

function fileClose(event) {
if (event.target.matches('#arrow')) {

document.querySelector('.file').style.display ='none';
}
}

////Fetch genres
fetch ('https://api.themoviedb.org/3/genre/movie/list?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR',{
method: 'GET',
headers : {
'Content-Type' : 'application.json'
}
})
.then(response=>response.json())
.then (response =>{
response.genres.forEach(file => {
document.querySelector('.file').innerHTML+= '<li>'+
'<a href="genre.html?id='+file.id+'"<p>'+file.name+'</p></a>'+
'</li>';
});
})

///////////////////////////////////////////////////////////////////////:
let queries = window.location.search // ?id=17521
 const paramsFilmo = new URLSearchParams(queries); // ['id': 17521]
 const visuelFilmo = 'https://image.tmdb.org/t/p/w500';
let page = paramsFilmo.page ? Number(paramsFilmo.page) : 1;
 
function genresMovies(id) {
 
    const Genres = `https://api.themoviedb.org/3/discover/movie?with_genres=${id}&api_key=02b73bb4996a66e2fb13ce6cd954dfab&language=fr`;
   
    fetch(Genres, {
        method: "GET",
        headers: {
            'Content-Type': 'application/json'
            
          }
    })
    
    .then(response => response.json())
    .then(movies => {
        movies.results.forEach(result => {
            let poster;
            let title = result.title ?? result.name;
    
            if(result.poster_path) {
                poster = `${visuelFilmo}${result.poster_path}`;
            }
            else {
                poster = 'img/default.svg';
            }
    
            document.querySelector('.picture__back--firstLine').innerHTML += `
                <a href="detail_film.html?id=${result.id}&media=${result.media_type}">
                    <img src="${poster}" alt="${title}">
                </a>
            `;
        });
    
    let right = document.querySelector('.arrow_right'); 
    
    if(page < movies.total_pages) {
        right.href = `genre.html?id=${id}&page=${page+1}`;
        right.querySelector('.picture__back--arrows--right').style.display = 'block';
    } else {
        right.querySelector('.picture__back--arrows--right').style.display = 'none';
    }
    
    
        let left = document.querySelector('.arrow_left');  
        if(page >= 2) {
            left.querySelector('.picture__back--arrows--left').style.display = 'block';
            left.href = `genre.html?id=${id}&page=${page-1}`;
        } else {
            left.querySelector('.picture__back--arrows--left').style.display = 'none';
        }
    })
    .catch(function(err) {
        console.log('Fetch Error :-S', err);
      });
      
}

genresMovies(paramsFilmo.get("id"));


