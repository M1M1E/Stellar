/////////////////////////clic logo ---> retour accueil/////////////////////////////////

document.querySelector('#logo-web').addEventListener('click', goIndex);
function goIndex() {
    location.href = 'index.html';
}



////////DROPDOWN MENU

let burger = document.querySelector('#burger');
burger.addEventListener('click', openMenu);

function openMenu() {
document.querySelector('ol').style.display = 'block';
}

//Close menu (mobile)
window.addEventListener('click', menuClose);

function menuClose(event) {
if (event.target.matches('.relative-menusearch')) {
document.querySelector('.file').style.display = 'none';
}

}

//desktop
let drop = document.querySelector('.relative-menusearch__mainMenu');
drop.addEventListener('click',openFile);

function openFile(){
document.querySelector('.file').style.display = 'block';
}

window.addEventListener('click', fileClose);

function fileClose(event) {
if (event.target.matches('#arrow')) {

document.querySelector('.file').style.display ='none';
}
}

////Fetch genres
fetch ('https://api.themoviedb.org/3/genre/movie/list?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR',{
method: 'GET',
headers : {
'Content-Type' : 'application.json'
}
})
.then(response=>response.json())
.then (response =>{
response.genres.forEach(file => {
document.querySelector('.file').innerHTML+= '<li>'+
'<a href="genre.html?id='+file.id+'"<p>'+file.name+'</p></a>'+
'</li>';
});
})

/*******************************************************************
 * 
 ******************************************************************/
/*let dropdown = document.querySelector('.header__class');

dropdown.querySelector('.header__class--button').addEventListener('click', function() {
    dropdown.querySelector('.listings').classList.toggle('listings--open');
});

window.addEventListener('click', function(event){
    if(!event.target.matches('.header__class')){
        document.querySelector('.listings').classList.add("hidden");
    }
});

fetch ('https://api.themoviedb.org/3/genre/movie/list?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR',{
    method: 'GET',
    headers : {
        'Content-Type': 'application/json'
    }
})
    .then (response => response.json())
    .then (response => {
        console.log(response)
        response.genres.forEach(listing => {
            document.querySelector('.listings ul').innerHTML+= '<li>'+
            '<a href="genres_movies.html?id='+listing.id+'"><p>'+listing.name+'</p></a>'+
            '</li>';
            
        }); 
    })*/


/********************************************************************
 * API FETCH
 * 
 ********************************************************************/
 let query = window.location.search // ?id=17521
 const params = new URLSearchParams(query); // ['id': 17521]
 
   function detailActor(id) {
 
     let urlDetail = 'https://api.themoviedb.org/3/person/' + id + '?api_key=02b73bb4996a66e2fb13ce6cd954dfab&language=fr';
    
     fetch(urlDetail, {
         method: "GET",
         headers: {
             'Content-Type': 'application/json'
             
           }
     })
     
     .then(response => response.json())
     .then(person => {
         //selection de la class pour afficher l'image récuperée
    document.querySelector('.back__picture--photo').src="https://image.tmdb.org/t/p/h632"+ person.profile_path;
    //affichage du nom
        document.querySelector('.back__picture--overlay--biopic--text--title').textContent = person.name;
        //affichage de la date de naissance
            document.querySelector('.back__picture--overlay--biopic--text').textContent = person.birthday;
            //affichage du lieu de naissance
            document.querySelector('.place').textContent = person.place_of_birth;
     })
     .catch(function(err) {
         console.log('Fetch Error :-S', err);
       });
       
 }
 
 detailActor(params.get("id"));
//////////////////////////////////////// 
///////////////////////////////////////////

/****************************************
 * Récupération de la filmographie de l'acteur
 */


let queries = window.location.search // ?id=17521
 const paramsFilmo = new URLSearchParams(queries); // ['id': 17521]
 const visuelFilmo = 'https://image.tmdb.org/t/p/w500';

 function filmographie(id) {
 fetch(`https://api.themoviedb.org/3/person/${id}/movie_credits?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR`,{
    method : 'GET',
    headers : {
        'Content-Type': 'application/json'
    }
})
.then ( response => response.json())
.then ((films) => {
    films.cast.forEach(film =>{
        let posterFilm;
        if(film.poster_path) {
            posterFilm = `${visuelFilmo}${film.poster_path}`;
        }
        else {
            posterFilm = 'img/default.svg';
        }
        document.querySelector('.cards__films').innerHTML+= `<a class="cards__films--img" href="./detail_film.html?id=${film.id}">
        <img class="cards__films--imgOne"
            src="https://image.tmdb.org/t/p/h632${film.poster_path}"
            alt="affiche film">
        <div class="cards__films--title">
            <p class="card-text">${films.title}</p>
        </div>
    </a>`
    })
   
})
 }
 filmographie(paramsFilmo.get("id"));

/////////////////////////////////////////////////
//desktop version
let queryDesktop = window.location.search // ?id=17521
const paramsDesktop = new URLSearchParams(queryDesktop); // ['id': 17521]
const visuelDesk = 'https://image.tmdb.org/t/p/w500';

function filmographieDesk(id) {

fetch (`https://api.themoviedb.org/3/person/${id}/movie_credits?api_key=d31b3c78860c89e16a7dc07680568b1c&language=fr-FR`,{
    method: 'GET',
    headers : {
        'Content-Type': 'application/json'
    }
})
    .then ( response => response.json())
    .then ((films) =>{
        films.cast.forEach(film =>{
            let poster;
            if(film.poster_path) {
                poster = `${visuelDesk}${film.poster_path}`;
            }
            else {
                poster = 'img/default.svg';
            }
            document.querySelector('.back__picture--overlay--cards__films').innerHTML+=` <a class="back__picture--overlay--cards__films--img" href="./detail_film.html?id=${film.id}">
            <img class="back__picture--overlay--cards__films--img"
                src="https://image.tmdb.org/t/p/h632${film.poster_path}"
                alt="affiche film">
            <div class="cards--title">
                <p class="card-text">${film.title}</p>
            </div>
        </a>`
        })
    })

}
filmographieDesk(paramsDesktop.get("id"));